/* omens plapinator theme */
(function cloudyplap() {
  if (window.__cloudyplap) return;
  if (new URLSearchParams(location.search).get("theme") === "0") return;
  window.__cloudyplap = true;

  const BASE = (document.currentScript && document.currentScript.src
    ? document.currentScript.src
    : "local/cloudyplap.js"
  ).replace(/[^/]+$/, "");

  const faces = document.createElement("link");
  faces.rel = "stylesheet";
  faces.href = BASE + "fonts/title-faces.css?v=2";
  document.head.appendChild(faces);
  const theme = document.createElement("link");
  theme.rel = "stylesheet";
  theme.href = BASE + "theme.css?v=2";
  document.head.appendChild(theme);

  document.body.classList.add("theme-cloudyplap");
  document.documentElement.style.background = "#000";

  const TITLE = "omens plapinator";
  document.title = TITLE;

  const brand = document.getElementById("brand-title");
  if (brand) {
    brand.hidden = true;
    brand.textContent = "";
  }

  function word(text) {
    const s = document.createElement("span");
    s.className = "brand-word";
    s.textContent = text;
    return s;
  }

  const mascot = document.createElement("button");
  mascot.type = "button";
  mascot.id = "omen-mascot";
  mascot.className = "brand-mascot";
  mascot.setAttribute("aria-label", TITLE);
  const mascotFrames = {
    idle: BASE + "assets/mascot-idle.png",
    half: BASE + "assets/mascot-wink-half.png",
    wink: BASE + "assets/mascot-wink.png",
    tongue: BASE + "assets/mascot-tongue.png",
  };
  const mascotImgs = {};
  Object.entries(mascotFrames).forEach(([key, src], i) => {
    const img = document.createElement("img");
    img.src = src;
    img.alt = "";
    img.dataset.face = key;
    if (key === "idle") img.classList.add("show");
    mascot.appendChild(img);
    mascotImgs[key] = img;
  });

  const sub = document.getElementById("brand-sub");
  if (sub) {
    sub.hidden = false;
    sub.classList.add("brand-lockup");
    sub.removeAttribute("role");
    sub.tabIndex = -1;
    sub.textContent = "";
    sub.appendChild(word("omens"));
    sub.appendChild(mascot);
    sub.appendChild(word("plapinator"));
  }
  theme.addEventListener("error", () => {
    document.body.classList.remove("theme-cloudyplap", "smoke-on");
    if (brand) {
      brand.hidden = false;
      brand.textContent = "GOONINATOR RELOADED";
    }
    if (sub) {
      sub.hidden = true;
      sub.textContent = "";
    }
    mascot.remove();
  });
  const node = document.getElementById("node-label");
  if (node) node.textContent = TITLE;
  const kicker = document.getElementById("player-kicker");
  if (kicker) kicker.textContent = TITLE;

  const topbar = document.querySelector(".topbar-actions");
  if (topbar) {
    document.getElementById("theme-preview-link")?.remove();
    if (!document.getElementById("public-preview-link")) {
      const back = document.createElement("a");
      back.className = "link";
      back.id = "public-preview-link";
      back.href = "?theme=0";
      back.textContent = "Public";
      topbar.appendChild(back);
    }
  }

  document.querySelectorAll('link[rel="apple-touch-icon"]').forEach((l) => {
    l.href = BASE + "assets/app-icon.png";
  });
  let apple = document.querySelector('link[rel="apple-touch-icon"]');
  if (!apple) {
    apple = document.createElement("link");
    apple.rel = "apple-touch-icon";
    document.head.appendChild(apple);
  }
  apple.href = BASE + "assets/app-icon.png";
  const og = document.querySelector('meta[property="og:image"]');
  if (og) og.setAttribute("content", BASE + "assets/share-card.jpg");
  const appTitle = document.querySelector('meta[name="apple-mobile-web-app-title"]');
  if (appTitle) appTitle.setAttribute("content", TITLE);

  const oldIntro = document.getElementById("intro-glitch");
  if (oldIntro) oldIntro.remove();

  const ghost = new Audio(BASE + "assets/ghost.mp3");
  ghost.preload = "auto";

  function armMascot() {
    document.body.classList.add("smoke-on");
    try {
      ghost.currentTime = 0;
      ghost.play();
    } catch {
      /* empty */
    }
  }
  mascot.addEventListener("click", armMascot);
  mascot.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      armMascot();
    }
  });

  function showFace(key) {
    Object.keys(mascotImgs).forEach((k) => {
      mascotImgs[k].classList.toggle("show", k === key);
    });
  }
  function playCartoon(seq, hold) {
    mascot.classList.remove("acting");
    void mascot.offsetWidth;
    mascot.classList.add("acting");
    let i = 0;
    const tick = () => {
      showFace(seq[i]);
      i += 1;
      if (i < seq.length) window.setTimeout(tick, hold);
      else window.setTimeout(() => mascot.classList.remove("acting"), 80);
    };
    tick();
  }
  function randomFace() {
    playCartoon(["tongue", "tongue", "tongue", "idle"], 220);
    window.setTimeout(randomFace, 4800 + Math.random() * 5000);
  }
  window.setTimeout(randomFace, 2200);

  const glow = document.createElement("div");
  glow.id = "void-glow";
  glow.setAttribute("aria-hidden", "true");
  document.body.appendChild(glow);

  const smokeVids = `
    <video class="smoke-vid a" muted loop playsinline preload="metadata" src="${BASE}assets/smoke-loop.mp4"></video>
    <video class="smoke-vid b" muted loop playsinline preload="metadata" src="${BASE}assets/smoke-loop.mp4"></video>
    <video class="smoke-vid c" muted loop playsinline preload="metadata" src="${BASE}assets/smoke-loop.mp4"></video>
    <div class="smoke-still" style="background-image:url(${BASE}assets/smoke-ref.jpg)"></div>
    <div class="smoke-still two" style="background-image:url(${BASE}assets/smoke-wisps.jpg)"></div>
  `;

  const player = document.getElementById("player");
  const reelSmoke = document.createElement("div");
  reelSmoke.id = "reel-smoke";
  reelSmoke.setAttribute("aria-hidden", "true");
  reelSmoke.innerHTML =
    smokeVids +
    `<div class="haze"></div><canvas id="smoke-particles"></canvas>`;
  if (player) player.insertBefore(reelSmoke, player.firstChild);

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const smokeVideos = [...reelSmoke.querySelectorAll(".smoke-vid")];
  const smokeActive = () =>
    !document.hidden &&
    !reduceMotion.matches &&
    document.body.classList.contains("smoke-on") &&
    player?.classList.contains("on");
  const syncSmokePlayback = () => {
    smokeVideos.forEach((video) => {
      if (smokeActive()) video.play().catch(() => undefined);
      else video.pause();
    });
  };
  new MutationObserver(syncSmokePlayback).observe(document.body, { attributes: true, attributeFilter: ["class"] });
  if (player) new MutationObserver(syncSmokePlayback).observe(player, { attributes: true, attributeFilter: ["class"] });
  document.addEventListener("visibilitychange", syncSmokePlayback);
  reduceMotion.addEventListener?.("change", syncSmokePlayback);

  function crossfadePair(scope) {
    const va = scope.querySelector(".smoke-vid.a");
    const vb = scope.querySelector(".smoke-vid.b");
    if (!va || !vb) return;
    try {
      vb.currentTime = 2.4;
    } catch {
      /* metadata not ready */
    }
    const vc = scope.querySelector(".smoke-vid.c");
    if (vc) {
      try {
        vc.currentTime = 4.1;
      } catch {
        /* metadata not ready */
      }
    }
    let showingA = true;
    const cross = () => {
      const fade = showingA ? va : vb;
      const rise = showingA ? vb : va;
      fade.style.transition = "opacity 1.4s linear";
      rise.style.transition = "opacity 1.4s linear";
      fade.style.opacity = "0.22";
      rise.style.opacity = "";
      showingA = !showingA;
    };
    va.addEventListener("timeupdate", () => {
      if (va.duration && va.currentTime > va.duration - 1.35 && showingA) cross();
    });
    vb.addEventListener("timeupdate", () => {
      if (vb.duration && vb.currentTime > vb.duration - 1.35 && !showingA) cross();
    });
  }
  crossfadePair(reelSmoke);

  const spriteA = new Image();
  spriteA.src = BASE + "assets/smoke-wisps.jpg";
  const spriteB = new Image();
  spriteB.src = BASE + "assets/smoke-ref.jpg";

  function engine(canvas, opts) {
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: true });
    let w = 0;
    let h = 0;
    const parts = [];
    const max = opts.max;
    const originY = opts.originY;
    let animationFrame = 0;
    let lastDraw = 0;

    function resize() {
      w = canvas.width = Math.floor(window.innerWidth * (window.devicePixelRatio > 1.5 ? 1.25 : 1));
      h = canvas.height = Math.floor(window.innerHeight * (window.devicePixelRatio > 1.5 ? 1.25 : 1));
      canvas.style.width = "100%";
      canvas.style.height = "100%";
    }
    window.addEventListener("resize", resize);
    resize();

    function spawn(n) {
      for (let i = 0; i < n; i++) {
        const side = Math.random();
        parts.push({
          x: w * (0.18 + Math.random() * 0.64),
          y: h * originY + (Math.random() - 0.3) * h * 0.08,
          r: (opts.sizeMin + Math.random() * opts.sizeMax) * (w / 1280),
          vx: (Math.random() - 0.5) * 0.42,
          vy: -0.18 - Math.random() * 0.55,
          life: 0,
          max: 280 + Math.random() * 420,
          swirl: Math.random() * Math.PI * 2,
          rot: Math.random() * Math.PI,
          spin: (Math.random() - 0.5) * 0.006,
          img: side > 0.45 ? spriteA : spriteB,
          flip: Math.random() < 0.5 ? -1 : 1,
        });
      }
    }
    spawn(opts.seed);

    function schedule() {
      if (!animationFrame && smokeActive()) animationFrame = requestAnimationFrame(frame);
    }

    function frame(t) {
      animationFrame = 0;
      if (!smokeActive()) return;
      if (t - lastDraw < 32) {
        schedule();
        return;
      }
      lastDraw = t;
      ctx.clearRect(0, 0, w, h);
      if (parts.length < max) spawn(opts.rate);
      ctx.globalCompositeOperation = "screen";
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i];
        p.swirl += 0.008;
        p.x += p.vx + Math.sin(p.swirl + t * 0.00035) * 0.55;
        p.y += p.vy;
        p.r *= 1.0018;
        p.rot += p.spin;
        p.life += 1;
        const fade = Math.max(0, 1 - p.life / p.max);
        const birth = Math.min(1, p.life / 36);
        const a = fade * birth * opts.alpha;
        if (a <= 0.01 || p.y < -p.r) {
          parts.splice(i, 1);
          continue;
        }
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.scale(p.flip, 1);
        ctx.globalAlpha = a;
        const img = p.img.complete && p.img.naturalWidth ? p.img : null;
        if (img) {
          ctx.drawImage(img, -p.r, -p.r * 0.72, p.r * 2, p.r * 1.44);
        } else {
          const g = ctx.createRadialGradient(0, 0, 0, 0, 0, p.r);
          g.addColorStop(0, "rgba(220,228,224,0.85)");
          g.addColorStop(0.4, "rgba(170,180,176,0.35)");
          g.addColorStop(1, "rgba(0,0,0,0)");
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.arc(0, 0, p.r, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }
      schedule();
    }
    new MutationObserver(schedule).observe(document.body, { attributes: true, attributeFilter: ["class"] });
    if (player) new MutationObserver(schedule).observe(player, { attributes: true, attributeFilter: ["class"] });
    document.addEventListener("visibilitychange", schedule);
    reduceMotion.addEventListener?.("change", schedule);
    schedule();
  }

  engine(document.getElementById("smoke-particles"), {
    max: 88,
    seed: 36,
    rate: 2,
    sizeMin: 110,
    sizeMax: 260,
    alpha: 0.38,
    originY: 0.88,
  });
})();
