const CACHE = "gooninator-reloaded-v17";
const PACK = "cloudyplap-pack-v3";
const SHELL = [
  "./",
  "./index.html",
  "./styles.css",
  "./app.js",
  "./fonts.css",
  "./vendor/jszip.min.js",
  "./favicon.svg",
  "./manifest.webmanifest",
  "./fonts/orbitron.woff2",
  "./fonts/share-tech-mono.woff2",
  "./fonts/f0.ttf",
  "./fonts/f3.ttf",
  "./fonts/f4.ttf",
  "./fonts/matrix-code-nfi.woff",
  "./fonts/matrix.woff",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(SHELL).catch(() => undefined)),
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => k !== CACHE && k !== PACK && !String(k).startsWith("cloudyplap-pack-"))
          .map((k) => caches.delete(k)),
      ),
    ),
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.protocol === "blob:" || url.protocol === "data:") return;
  if (/soundcloud\.com|snd\.sc|w\.soundcloud/.test(url.hostname)) return;
  event.respondWith(
    (async () => {
      if (url.origin === location.origin && url.pathname.includes("/local/")) {
        const pack = await caches.open(PACK);
        const packed =
          (await pack.match(req)) ||
          (await pack.match(url.href)) ||
          (await pack.match(url.pathname));
        if (packed) return packed;
      }
      const hit = await caches.match(req);
      if (hit) return hit;
      try {
        const res = await fetch(req);
        const neuralHost = /jsdelivr\.net|huggingface\.co|hf\.co|cdn-lfs/.test(url.hostname);
        if (res.ok && (url.origin === location.origin || neuralHost)) {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy));
        }
        return res;
      } catch {
        return caches.match("./index.html");
      }
    })(),
  );
});
